# Ethix-MD

<p align="center">
  <a href="https://youtu.be/WcA7GZuaN0A">
    <img alt="Ethix-MD" height="300" src="https://telegra.ph/file/fbbe1744668b44637c21a.jpg">
  </a>
</p>

<p align="center">
  <a href="https://github.com/Ethix-Xsid"><img title="Author" src="https://img.shields.io/badge/Ethix-Xsid-black?style=for-the-badge&logo=WhatsApp"></a>
</p>

<p align="center">Introducing Ethix-MD, It is designed to bring a whole new level of excitement to your boring WhatsApp use.</p>

<p align="center">
  <a aria-label="Ethix-MD is free to use" href="https://youtube.com/@mhmodsofc" target="_blank">
    <img alt="MH MODS OFC Yt" src="https://img.shields.io/youtube/channel/subscribers/UCWHA-PreVSVaYhDTAiUipCA" target="_blank" />
  </a>
</p>

<p align="center"><img src="https://profile-counter.glitch.me/{chhaseeb47}/count.svg" alt="chhaseeb47 :: Visitor's Count" /></p>

<p align="center">
  <a href="https://whatsapp.com/channel/0029Va8SjGU1noyxsYBA2K2e"><img src="https://img.shields.io/badge/Connect on WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
  <a href="https://www.youtube.com/channel/UCWHA-PreVSVaYhDTAiUipCA"><img src="https://img.shields.io/badge/Subcribe On Youtube-E4405F?style=for-the-badge&logo=youtube&logoColor=white"></a>
  <a href="https://whatsapp.com/channel/0029VaFNrVHBfxoBuY2TzH2w"><img src="https://img.shields.io/badge/Join WhatsApp Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

<p align="center">
  <a href="https://github.com/Ethix-Xsid/followers"><img title="Followers" src="https://img.shields.io/github/followers/Ethix-Xsid?color=red&style=flat-square"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/Ethix-Xsid/Ethix-MD?color=blue&style=flat-square"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Ethix-Xsid/Ethix-MD?color=red&style=flat-square"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Ethix-Xsid/Ethix-MD?label=Watchers&color=blue&style=flat-square"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD"><img title="Open Source" src="https://img.shields.io/badge/Author-ETHIX SID X %20HASEEB-red?v=103"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD"><img title="Size" src="https://img.shields.io/github/repo-size/Ethix-Xsid/Ethix-MD?style=flat-square&color=green"></a>
  <a href="https://github.com/Ethix-Xsid/Ethix-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>

---

### 1. FORK THIS REPO

<a href='https://github.com/Ethix-Xsid/Ethix-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>

### 2. GET SESSION ID VIA PAIR CODE

<a href='https://toxic-crocodile-goutammallick516-cab1ca96.koyeb.app' target="_blank"><img alt='Get Session ID' src='https://img.shields.io/badge/Click here to get your session id-blue?style=for-the-badge&logo=opencv&logoColor=white'/></a>

### DEPLOY TO HEROKU

1. If you don't have an account in Heroku, create one.
    <br>
    <a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>
2. Now deploy.
    <br>
    <a href='https://heroku.com/deploy' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>



3. ## Deploy to Koyeb ↓

<a href="https://app.koyeb.com/services/deploy/?type=git&repository=github.com%2FEthix-Xsid%2FEthix-MD&branch=main&name=ethix-md&builder=dockerfile&env%5BAUTO_BLOCK=false%5D=&env%5BSESSION_ID%5D=your%20sessionid%20here&env%5BMODE%5D=public&env=%5BAUTO_READ%5D%3Dfalse&env%5BAUTO_STATUS_SEEN%5D=true" target="blank"><img align="center" src="https://i.imgur.com/PNoLtFq.png" width="300" height="100" alt="Deploy bot"/></a>




## DEVELOPERS

<div align="left">
  <a href="https://github.com/Ethix-Xsid"><img src="https://telegra.ph/file/fbbe1744668b44637c21a.jpg" width="300" height="200" alt="Sid"></a>
  
  | [SIDHARTH](https://github.com/Ethix-Xsid) |
  | Owner, Developer, Bug Fixer, Maintainer, updates |
</div>

## HELPERS

<a href="https://github.com/chhaseeb47"><img src="https://github.com/chhaseeb47.png?size=100" width="130" height="100"></a> | [<img src="https://github.com/Rushmaster12.png?size=100" width="100" height="100">](https://github.com/Rushmaster12) 
---|---
[CH HASEEB](https://github.com/Ajmal-Achu)  | [RUSHMASTER](https://github.com/Rushmaster12)
Promotion | Groups Management|


## Reminder

- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!` (Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.

---

<h1 align="center">Keep Supporting</h1>

<br>

## Contact

<p align="left">
  <a href="mailto:bsid4961@gmail.com"><img title="Author" src="https://img.shields.io/badge/GMAIL-ME-black?style=for-the-badge&logo=Gmail"></a>
  <a href="https://wa.me/919142294671?text=Hi+sid+Sir...+I+need+some+help+in+Ethix-MD"><img title="Author" src="https://img.shields.io/badge/WHATSAPP-ME-red?style=for-the-badge&logo=WhatsApp"></a>
</p>
